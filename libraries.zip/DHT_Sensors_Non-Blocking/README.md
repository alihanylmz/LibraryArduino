# Arduino  library DHT-Sensors-Non-Blocking

## Description

An Arduino library for the DHT sensor family (DHT11, DHT22,...). With Non-Blocking design to optimize CPU performance.

